

<!-- ফুটার শুরু -->
<footer class="footer bg-dark" style="height: 50px;">
    <div class="container text-center pt-3">
        <span class="text-white">all right reserved &copy; varsitypathinfo. </span>
    </div>
</footer>
<!-- ফুটার শেষ -->



<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<?php wp_footer(); ?>
</body>
</html>