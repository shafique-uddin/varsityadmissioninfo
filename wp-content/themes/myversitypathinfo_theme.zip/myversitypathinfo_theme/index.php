<?php get_header(); ?>


<!-- জাম্বোট্রন এর কাজ শুরু -->
        <div class="row">
            <div class="col">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-5">এ পর্যন্ত প্রকাশিত সকল বিশ্ববিদ্যালয়ের ভর্তি সার্কুলার নিম্নরূপঃ</h1>
                        <hr class="my-2">
                        <p>সমস্যা নেই। সমাধান আছে আমাদের কাছে।</p>
                    </div>
                </div>
            </div>
        </div>
    <!-- জাম্বোট্রন এর কাজ শেষ -->    




<?php 
    while (have_posts()) : the_post(); ?>
        <h1> <?php echo get_the_title(); ?></h1>
        <p> <?php the_content() ?> </p>
<?php endwhile; ?>


<?php get_footer(); ?>