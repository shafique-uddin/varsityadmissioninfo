<?php 

/**
 * Template Name: Search Result Page
 */

get_header();
?>

<?php 

if (!empty($_GET['sscgpa']) && !empty($_GET['sscgrp']) && !empty($_GET['hscgpa']) && !empty($_GET['hscgrp']) && !empty($_GET['submit'])) { 
    $sscgpa = floatval($_GET['sscgpa']);
    $sscgrp = $_GET['sscgrp'];
    $hscgpa = floatval($_GET['hscgpa']);
    $hscgrp = $_GET['hscgrp'];

    ?>



    <!-- Start Content area Jumbotron -->
    <div class="jumbotron jumbotron-fluid text-white bg-dark">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p>আপনার মোট জিপিএ = <?php echo $sscgpa + $hscgpa; ?></p>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <p>যোগ্যতা অনুযায়ী যে সকল বিশ্ববিদ্যালয়ের বিভিন্ন ইউনিটে আপনি পরীক্ষা দিতে পারবেন তা নিম্নরূপ -</p>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <table class="table table-success table-striped table-hover">
                        <thead>
                            <tr>
                                <th scope="col">বিশ্ববিদ্যালয়ের নাম</th>
                                <th scope="col">ইউনিটের নাম</th>
                                <th scope="col">বিস্তারিত তথ্যসমূহ</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="col">ঢাকা বিশ্ববিদ্যালয়</th>
                                <td scope="col">ক ইউনিট</td>
                                <td scope="col">ক্লিক করুন</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- End Content area -->



    
<?php }
else { ?>

<div class="container-fluid">
    <!-- Start Content area Jumbotron -->
    <div class="jumbotron jumbotron-fluid text-white bg-dark">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1 class="fs-3 text-center mb-4">দুঃখিত! <br> আপনার কাঙ্ক্ষিত তথ্য খুজে পাওয়া যায়নি।<br> নিশ্চয়ই আপনার ভুল হয়েছে।</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End Content area -->
</div>

<?php }

?>

<?php get_footer(); ?>