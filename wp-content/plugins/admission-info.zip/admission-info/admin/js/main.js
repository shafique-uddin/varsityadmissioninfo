jQuery.noConflict();
(function( $ ) {
  $(function() {
    $( "#datepicker" ).datepicker({
        changeMonth: true,
        changeYear: true
      });
  });
})(jQuery);